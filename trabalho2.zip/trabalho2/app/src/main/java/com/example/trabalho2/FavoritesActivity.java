package com.example.trabalho2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.trabalho2.db.FractalDbHelper;
import com.example.trabalho2.ui.FractalConfigFragment;

import java.util.Locale;

/**
 * Activity secundária aberta via Intent explícita a partir da MainActivity.
 * Consulta e lista as configurações salvas no banco de dados SQLite retornando
 * os dados em um Cursor através do método query().
 */
public class FavoritesActivity extends AppCompatActivity {

    private FractalDbHelper dbHelper;
    private Cursor cursor;
    private SimpleCursorAdapter adapter;
    private ListView lvFavorites;
    private TextView tvEmpty;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        lvFavorites = findViewById(R.id.lv_favorites);
        tvEmpty = findViewById(R.id.tv_empty_favorites);
        btnVoltar = findViewById(R.id.btn_voltar_main);

        dbHelper = new FractalDbHelper(this);

        // Listagem dos dados salvos no SQLite utilizando Cursor retornado de db.query()
        carregarFavoritosDoBanco();

        // Acionamento de botão com setOnClickListener para retornar à MainActivity
        btnVoltar.setOnClickListener(v -> finish());

        // Clique em um item favorito para carregá-lo na calculadora via Intent explícita
        lvFavorites.setOnItemClickListener((parent, view, position, id) -> {
            if (cursor != null && cursor.moveToPosition(position)) {
                String nome = cursor.getString(cursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_NAME));
                String tipo = cursor.getString(cursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_TYPE));
                double cx = cursor.getDouble(cursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_CENTER_X));
                double cy = cursor.getDouble(cursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_CENTER_Y));
                double zoom = cursor.getDouble(cursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_ZOOM));
                int maxIter = cursor.getInt(cursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_MAX_ITER));
                double cr = cursor.getDouble(cursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_C_REAL));
                double ci = cursor.getDouble(cursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_C_IMAG));

                // Navegação via Intent explícita enviando os parâmetros de volta para a MainActivity
                Intent intent = new Intent(FavoritesActivity.this, MainActivity.class);
                intent.putExtra(FractalConfigFragment.ARG_NAME, nome);
                intent.putExtra(FractalConfigFragment.ARG_TYPE, tipo);
                intent.putExtra(FractalConfigFragment.ARG_CENTER_X, cx);
                intent.putExtra(FractalConfigFragment.ARG_CENTER_Y, cy);
                intent.putExtra(FractalConfigFragment.ARG_ZOOM, zoom);
                intent.putExtra(FractalConfigFragment.ARG_MAX_ITER, maxIter);
                intent.putExtra(FractalConfigFragment.ARG_C_REAL, cr);
                intent.putExtra(FractalConfigFragment.ARG_C_IMAG, ci);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            }
        });

        // Clique longo para exclusão do favorito no SQLite
        lvFavorites.setOnItemLongClickListener((parent, view, position, id) -> {
            int rowsDeleted = dbHelper.deleteFavorite(id);
            if (rowsDeleted > 0) {
                Toast.makeText(this, "Favorito removido do SQLite.", Toast.LENGTH_SHORT).show();
                carregarFavoritosDoBanco();
                return true;
            }
            return false;
        });
    }

    /**
     * Consulta o SQLite através de dbHelper.getAllFavoritesCursor() (que utiliza db.query())
     * e vincula o Cursor à ListView através do SimpleCursorAdapter.
     */
    private void carregarFavoritosDoBanco() {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }

        // Obtém o Cursor do SQLite retornado pelo método query()
        cursor = dbHelper.getAllFavoritesCursor();

        if (cursor.getCount() == 0) {
            tvEmpty.setVisibility(View.VISIBLE);
            lvFavorites.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            lvFavorites.setVisibility(View.VISIBLE);

            String[] fromColumns = {
                    FractalDbHelper.COLUMN_NAME,
                    FractalDbHelper.COLUMN_TYPE,
                    FractalDbHelper.COLUMN_CENTER_X
            };

            int[] toViews = {
                    R.id.tv_item_name,
                    R.id.tv_item_details,
                    R.id.tv_item_coords
            };

            adapter = new SimpleCursorAdapter(
                    this,
                    R.layout.item_favorite,
                    cursor,
                    fromColumns,
                    toViews,
                    0
            );

            // Custom ViewBinder para formatar os dados textuais do Cursor
            adapter.setViewBinder((view, aCursor, columnIndex) -> {
                int colType = aCursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_TYPE);
                int colZoom = aCursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_ZOOM);
                int colIter = aCursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_MAX_ITER);
                int colCx = aCursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_CENTER_X);
                int colCy = aCursor.getColumnIndexOrThrow(FractalDbHelper.COLUMN_CENTER_Y);

                if (view.getId() == R.id.tv_item_details) {
                    String tipo = aCursor.getString(colType);
                    double zoom = aCursor.getDouble(colZoom);
                    int iter = aCursor.getInt(colIter);
                    String details = String.format(Locale.getDefault(),
                            "Tipo: %s | Zoom: %.1fx | Máx Iter: %d", tipo, zoom, iter);
                    ((TextView) view).setText(details);
                    return true;
                } else if (view.getId() == R.id.tv_item_coords) {
                    double cx = aCursor.getDouble(colCx);
                    double cy = aCursor.getDouble(colCy);
                    String coords = String.format(Locale.getDefault(),
                            "Centro: (%.4f, %.4f)", cx, cy);
                    ((TextView) view).setText(coords);
                    return true;
                }
                return false;
            });

            lvFavorites.setAdapter(adapter);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}
