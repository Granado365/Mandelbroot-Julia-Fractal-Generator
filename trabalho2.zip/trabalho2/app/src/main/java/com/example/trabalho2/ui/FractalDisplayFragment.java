package com.example.trabalho2.ui;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.trabalho2.R;
import com.example.trabalho2.db.FractalDbHelper;
import com.example.trabalho2.fractal.FractalCallable;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Fragment de exibição onde a imagem do fractal é renderizada em um Canvas.
 * Recebe os parâmetros através de Bundle e getArguments().
 * Utiliza Executors.newSingleThreadExecutor(), Callable e Future para cálculo assíncrono
 * e prevenção de travamentos na thread de UI (evitando ANR).
 */
public class FractalDisplayFragment extends Fragment {

    private FractalCanvasView fractalCanvasView;
    private ProgressBar progressBar;
    private TextView tvDisplayInfo;
    private Button btnVoltar;
    private Button btnSalvar;

    private String tipo = "Mandelbrot";
    private String nome = "Fractal";
    private double centroX = -0.7;
    private double centroY = 0.0;
    private double zoom = 1.0;
    private int maxIter = 100;
    private double cReal = -0.7;
    private double cImag = 0.27015;

    public FractalDisplayFragment() {
        // Construtor público obrigatório
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fractal_display, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        fractalCanvasView = view.findViewById(R.id.fractal_canvas_view);
        progressBar = view.findViewById(R.id.pb_calculating);
        tvDisplayInfo = view.findViewById(R.id.tv_display_info);
        btnVoltar = view.findViewById(R.id.btn_voltar_config);
        btnSalvar = view.findViewById(R.id.btn_salvar_display);

        extrairParametrosDoBundle();
        configurarBotoes();
        executarCalculoFractal();
    }

    private void extrairParametrosDoBundle() {
        Bundle args = getArguments();
        if (args != null) {
            tipo = args.getString(FractalConfigFragment.ARG_TYPE, "Mandelbrot");
            nome = args.getString(FractalConfigFragment.ARG_NAME, "Fractal");
            centroX = args.getDouble(FractalConfigFragment.ARG_CENTER_X, -0.7);
            centroY = args.getDouble(FractalConfigFragment.ARG_CENTER_Y, 0.0);
            zoom = args.getDouble(FractalConfigFragment.ARG_ZOOM, 1.0);
            maxIter = args.getInt(FractalConfigFragment.ARG_MAX_ITER, 100);
            cReal = args.getDouble(FractalConfigFragment.ARG_C_REAL, -0.7);
            cImag = args.getDouble(FractalConfigFragment.ARG_C_IMAG, 0.27015);
        }

        String info = String.format(Locale.getDefault(),
                "Tipo: %s | Centro: (%.4f, %.4f) | Zoom: %.2fx | Iter: %d",
                tipo, centroX, centroY, zoom, maxIter);
        if ("Julia".equalsIgnoreCase(tipo)) {
            info += String.format(Locale.getDefault(), " | c=(%.4f + %.4fi)", cReal, cImag);
        }
        tvDisplayInfo.setText(info);
    }

    private void configurarBotoes() {
        // Botão para retornar ao Fragment de configuração via FragmentManager
        btnVoltar.setOnClickListener(v -> {
            if (getParentFragmentManager().getBackStackEntryCount() > 0) {
                getParentFragmentManager().popBackStack();
            } else {
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new FractalConfigFragment())
                        .commit();
            }
        });

        // Botão para salvar no SQLite a partir da tela de visualização
        btnSalvar.setOnClickListener(v -> {
            try (FractalDbHelper dbHelper = new FractalDbHelper(requireContext())) {
                long id = dbHelper.insertFavorite(nome, tipo, centroX, centroY, zoom, maxIter, cReal, cImag);
                if (id != -1) {
                    Toast.makeText(requireContext(), "Fractal '" + nome + "' salvo nos favoritos!",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(requireContext(), "Erro ao salvar no SQLite.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Executa o algoritmo de geração do fractal chamando Executors.newSingleThreadExecutor().
     * Processa a matemática em uma interface Callable e obtém a resposta através de Future.
     * Desta forma, a thread principal (UI) permanece totalmente responsiva, prevenindo o erro ANR.
     */
    private void executarCalculoFractal() {
        progressBar.setVisibility(View.VISIBLE);

        // 1. Instanciação do Executor com newSingleThreadExecutor()
        ExecutorService calculationExecutor = Executors.newSingleThreadExecutor();

        // 2. Processamento da matemática em uma interface Callable<Bitmap>
        FractalCallable fractalCallable = new FractalCallable(
                tipo, centroX, centroY, zoom, maxIter, cReal, cImag, 700, 700
        );

        // 3. Submissão do Callable ao Executor obtendo a resposta através de Future<Bitmap>
        Future<Bitmap> fractalFuture = calculationExecutor.submit(fractalCallable);

        // 4. Thread em segundo plano para aguardar o Future.get() sem travar a UI Thread
        long startTime = System.currentTimeMillis();
        ExecutorService monitorExecutor = Executors.newSingleThreadExecutor();
        monitorExecutor.execute(() -> {
            try {
                // Obtém a resposta computada do Future
                Bitmap resultBitmap = fractalFuture.get();
                long elapsedTime = System.currentTimeMillis() - startTime;

                // Atualiza os componentes visuais na Thread Principal
                if (isAdded() && getActivity() != null) {
                    requireActivity().runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        // Renderização direta no Canvas da View customizada
                        fractalCanvasView.setBitmap(resultBitmap);

                        String tempoStr = String.format(Locale.getDefault(),
                                "%s renderizado no Canvas em %d ms! (Zoom: %.1fx, Iter: %d)",
                                tipo, elapsedTime, zoom, maxIter);
                        tvDisplayInfo.setText(tempoStr);
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                if (isAdded() && getActivity() != null) {
                    requireActivity().runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        tvDisplayInfo.setText("Falha no cálculo: " + e.getMessage());
                    });
                }
            } finally {
                calculationExecutor.shutdown();
                monitorExecutor.shutdown();
            }
        });
    }
}
