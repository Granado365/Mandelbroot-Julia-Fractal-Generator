package com.example.trabalho2.fractal;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.concurrent.Callable;

/**
 * Interface Callable que executa o cálculo matemático intensivo dos fractais
 * de Mandelbrot e Julia em uma thread de trabalho para evitar o erro ANR.
 * Retorna um Bitmap gerado com as cores calculadas para cada coordenada complexa.
 */
public class FractalCallable implements Callable<Bitmap> {

    private final String type;
    private final double centerX;
    private final double centerY;
    private final double zoom;
    private final int maxIterations;
    private final double cReal;
    private final double cImag;
    private final int width;
    private final int height;

    public FractalCallable(String type, double centerX, double centerY, double zoom,
                           int maxIterations, double cReal, double cImag,
                           int width, int height) {
        this.type = type;
        this.centerX = centerX;
        this.centerY = centerY;
        this.zoom = zoom;
        this.maxIterations = maxIterations;
        this.cReal = cReal;
        this.cImag = cImag;
        this.width = width > 0 ? width : 600;
        this.height = height > 0 ? height : 600;
    }

    @Override
    public Bitmap call() {
        int[] pixels = new int[width * height];
        boolean isJulia = "Julia".equalsIgnoreCase(type);

        // Razão de aspecto e escala base
        double aspectRatio = (double) width / (double) height;
        double scaleY = 3.0 / (zoom * height);
        double scaleX = (3.0 * aspectRatio) / (zoom * width);

        for (int y = 0; y < height; y++) {
            double currentImag = centerY + (y - (height / 2.0)) * scaleY;

            for (int x = 0; x < width; x++) {
                double currentReal = centerX + (x - (width / 2.0)) * scaleX;

                int iterations;
                if (isJulia) {
                    iterations = calculateJulia(currentReal, currentImag);
                } else {
                    iterations = calculateMandelbrot(currentReal, currentImag);
                }

                pixels[y * width + x] = getColorForIteration(iterations);
            }
        }

        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888);
    }

    /**
     * Conjunto de Mandelbrot:
     * z_0 = 0
     * z_{n+1} = z_n^2 + c
     * c = x0 + i*y0
     */
    private int calculateMandelbrot(double cX, double cY) {
        double zx = 0.0;
        double zy = 0.0;
        double zx2 = 0.0;
        double zy2 = 0.0;
        int iter = 0;

        while (iter < maxIterations && (zx2 + zy2) <= 4.0) {
            zy = 2.0 * zx * zy + cY;
            zx = zx2 - zy2 + cX;
            zx2 = zx * zx;
            zy2 = zy * zy;
            iter++;
        }

        return iter;
    }

    /**
     * Conjunto de Julia:
     * z_0 = x0 + i*y0
     * z_{n+1} = z_n^2 + c
     * c = constante fixa (cReal + i*cImag)
     */
    private int calculateJulia(double zx, double zy) {
        double zx2 = zx * zx;
        double zy2 = zy * zy;
        int iter = 0;

        while (iter < maxIterations && (zx2 + zy2) <= 4.0) {
            zy = 2.0 * zx * zy + cImag;
            zx = zx2 - zy2 + cReal;
            zx2 = zx * zx;
            zy2 = zy * zy;
            iter++;
        }

        return iter;
    }

    /**
     * Mapeia o número de iterações em um gradiente de cores suave e estético.
     * Pontos interiores ao conjunto recebem a cor preta.
     */
    private int getColorForIteration(int iter) {
        if (iter >= maxIterations) {
            return Color.BLACK;
        }

        // Gera matiz circular (Hue) baseada nas iterações
        float hue = (float) ((iter * 9.0f) % 360.0f);
        float saturation = 0.85f;
        float value = 1.0f;

        return Color.HSVToColor(new float[]{hue, saturation, value});
    }
}
