package com.example.trabalho2.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * View personalizada onde a imagem do fractal é renderizada diretamente em um Canvas.
 */
public class FractalCanvasView extends View {

    private Bitmap fractalBitmap;
    private final Paint paint;
    private final Paint borderPaint;
    private final Paint textPaint;
    private final Rect srcRect;
    private final RectF destRect;

    public FractalCanvasView(Context context) {
        this(context, null);
    }

    public FractalCanvasView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FractalCanvasView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setColor(Color.DKGRAY);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(4f);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.LTGRAY);
        textPaint.setTextSize(36f);
        textPaint.setTextAlign(Paint.Align.CENTER);

        srcRect = new Rect();
        destRect = new RectF();
    }

    public void setBitmap(Bitmap bitmap) {
        this.fractalBitmap = bitmap;
        invalidate(); // Solicita nova execução do onDraw(Canvas)
    }

    public Bitmap getBitmap() {
        return fractalBitmap;
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);

        int viewWidth = getWidth();
        int viewHeight = getHeight();

        // Fundo escuro elegante
        canvas.drawColor(Color.BLACK);

        if (fractalBitmap != null && !fractalBitmap.isRecycled()) {
            srcRect.set(0, 0, fractalBitmap.getWidth(), fractalBitmap.getHeight());

            // Centraliza e mantém proporção mantendo aspecto quadrado
            int size = Math.min(viewWidth, viewHeight);
            float left = (viewWidth - size) / 2.0f;
            float top = (viewHeight - size) / 2.0f;
            destRect.set(left, top, left + size, top + size);

            // Renderização do fractal no Canvas
            canvas.drawBitmap(fractalBitmap, srcRect, destRect, paint);

            // Desenha borda estilizada
            canvas.drawRect(destRect, borderPaint);
        } else {
            // Texto indicativo caso não haja bitmap pronto
            canvas.drawText("Aguardando renderização do fractal...",
                    viewWidth / 2.0f, viewHeight / 2.0f, textPaint);
        }
    }
}
