package com.example.trabalho2.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Gerenciador de Banco de Dados SQLite para persistência das configurações de fractais.
 * Implementa SQLiteOpenHelper declarando onCreate e onUpgrade.
 * Utiliza ContentValues para inserção (insert) e Cursor para consulta (query).
 */
public class FractalDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "fractais.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_FAVORITES = "favoritos";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "nome";
    public static final String COLUMN_TYPE = "tipo";
    public static final String COLUMN_CENTER_X = "centro_x";
    public static final String COLUMN_CENTER_Y = "centro_y";
    public static final String COLUMN_ZOOM = "zoom";
    public static final String COLUMN_MAX_ITER = "max_iter";
    public static final String COLUMN_C_REAL = "c_real";
    public static final String COLUMN_C_IMAG = "c_imag";

    private static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + TABLE_FAVORITES + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAME + " TEXT NOT NULL, " +
                    COLUMN_TYPE + " TEXT NOT NULL, " +
                    COLUMN_CENTER_X + " REAL NOT NULL, " +
                    COLUMN_CENTER_Y + " REAL NOT NULL, " +
                    COLUMN_ZOOM + " REAL NOT NULL, " +
                    COLUMN_MAX_ITER + " INTEGER NOT NULL, " +
                    COLUMN_C_REAL + " REAL, " +
                    COLUMN_C_IMAG + " REAL" +
                    ");";

    private static final String SQL_DROP_TABLE =
            "DROP TABLE IF EXISTS " + TABLE_FAVORITES;

    public FractalDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE);

        // Insere configurações iniciais de exemplo como favoritos padrão
        inserirPadrao(db, "Mandelbrot Padrão", "Mandelbrot", -0.7, 0.0, 1.0, 100, 0.0, 0.0);
        inserirPadrao(db, "Mandelbrot Vale dos Cavalos-Marinhos", "Mandelbrot", -0.743643887037158704752191506114774, 0.131825904205311970493132056385139, 150.0, 200, 0.0, 0.0);
        inserirPadrao(db, "Julia Dendrite Clássica", "Julia", 0.0, 0.0, 1.0, 150, -0.4, 0.6);
        inserirPadrao(db, "Julia Espiral San Marco", "Julia", 0.0, 0.0, 1.0, 150, -0.7, 0.27015);
        inserirPadrao(db, "Julia Flor de Gelo", "Julia", 0.0, 0.0, 1.0, 150, -0.8, 0.156);
    }

    private void inserirPadrao(SQLiteDatabase db, String nome, String tipo, double cx, double cy,
                               double zoom, int maxIter, double cr, double ci) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, nome);
        values.put(COLUMN_TYPE, tipo);
        values.put(COLUMN_CENTER_X, cx);
        values.put(COLUMN_CENTER_Y, cy);
        values.put(COLUMN_ZOOM, zoom);
        values.put(COLUMN_MAX_ITER, maxIter);
        values.put(COLUMN_C_REAL, cr);
        values.put(COLUMN_C_IMAG, ci);
        db.insert(TABLE_FAVORITES, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DROP_TABLE);
        onCreate(db);
    }

    /**
     * Salva uma configuração de fractal utilizando ContentValues e o método insert().
     */
    public long insertFavorite(String nome, String tipo, double centerX, double centerY,
                               double zoom, int maxIter, double cReal, double cImag) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, nome);
        values.put(COLUMN_TYPE, tipo);
        values.put(COLUMN_CENTER_X, centerX);
        values.put(COLUMN_CENTER_Y, centerY);
        values.put(COLUMN_ZOOM, zoom);
        values.put(COLUMN_MAX_ITER, maxIter);
        values.put(COLUMN_C_REAL, cReal);
        values.put(COLUMN_C_IMAG, cImag);

        return db.insert(TABLE_FAVORITES, null, values);
    }

    /**
     * Retorna um Cursor com todas as configurações salvas utilizando o método query().
     */
    public Cursor getAllFavoritesCursor() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                COLUMN_ID,
                COLUMN_NAME,
                COLUMN_TYPE,
                COLUMN_CENTER_X,
                COLUMN_CENTER_Y,
                COLUMN_ZOOM,
                COLUMN_MAX_ITER,
                COLUMN_C_REAL,
                COLUMN_C_IMAG
        };

        return db.query(
                TABLE_FAVORITES,
                projection,
                null,
                null,
                null,
                null,
                COLUMN_ID + " DESC"
        );
    }

    /**
     * Remove uma configuração pelo ID.
     */
    public int deleteFavorite(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_FAVORITES, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }
}
