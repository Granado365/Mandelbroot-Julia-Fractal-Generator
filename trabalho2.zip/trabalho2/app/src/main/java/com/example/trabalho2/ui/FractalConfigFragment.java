package com.example.trabalho2.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.trabalho2.R;
import com.example.trabalho2.db.FractalDbHelper;

/**
 * Fragment de configuração onde o usuário insere os parâmetros matemáticos do fractal.
 * Transfere dados para o Fragment de exibição através de Bundle e setArguments().
 * Utiliza componentes android.widget como Button, EditText, RadioButton e LinearLayout.
 */
public class FractalConfigFragment extends Fragment {

    public static final String ARG_TYPE = "fractal_type";
    public static final String ARG_NAME = "fractal_name";
    public static final String ARG_CENTER_X = "center_x";
    public static final String ARG_CENTER_Y = "center_y";
    public static final String ARG_ZOOM = "zoom";
    public static final String ARG_MAX_ITER = "max_iterations";
    public static final String ARG_C_REAL = "c_real";
    public static final String ARG_C_IMAG = "c_imag";

    private RadioGroup rgFractalType;
    private RadioButton rbMandelbrot;
    private RadioButton rbJulia;
    private LinearLayout layoutJuliaParams;

    private EditText etNome;
    private EditText etCentroX;
    private EditText etCentroY;
    private EditText etZoom;
    private EditText etMaxIter;
    private EditText etCReal;
    private EditText etCImag;

    private Button btnCalcular;
    private Button btnSalvarDb;
    private Button btnPresetMandelbrot;
    private Button btnPresetSeahorse;
    private Button btnPresetJulia;

    public FractalConfigFragment() {
        // Construtor público obrigatório para Fragments
    }

    public static FractalConfigFragment newInstance(Bundle initialParams) {
        FractalConfigFragment fragment = new FractalConfigFragment();
        if (initialParams != null) {
            fragment.setArguments(initialParams);
        }
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fractal_config, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Inicialização de widgets
        rgFractalType = view.findViewById(R.id.rg_fractal_type);
        rbMandelbrot = view.findViewById(R.id.rb_mandelbrot);
        rbJulia = view.findViewById(R.id.rb_julia);
        layoutJuliaParams = view.findViewById(R.id.layout_julia_params);

        etNome = view.findViewById(R.id.et_nome);
        etCentroX = view.findViewById(R.id.et_centro_x);
        etCentroY = view.findViewById(R.id.et_centro_y);
        etZoom = view.findViewById(R.id.et_zoom);
        etMaxIter = view.findViewById(R.id.et_max_iter);
        etCReal = view.findViewById(R.id.et_c_real);
        etCImag = view.findViewById(R.id.et_c_imag);

        btnCalcular = view.findViewById(R.id.btn_calcular);
        btnSalvarDb = view.findViewById(R.id.btn_salvar_db);
        btnPresetMandelbrot = view.findViewById(R.id.btn_preset_mandelbrot);
        btnPresetSeahorse = view.findViewById(R.id.btn_preset_seahorse);
        btnPresetJulia = view.findViewById(R.id.btn_preset_julia);

        configurarListeners();
        carregarArgumentosIniciais();
    }

    private void configurarListeners() {
        // Alternância de campos para Mandelbrot vs Julia
        rgFractalType.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rb_julia) {
                layoutJuliaParams.setVisibility(View.VISIBLE);
                if (etCentroX.getText().toString().equals("-0.7")) {
                    etCentroX.setText("0.0");
                }
            } else {
                layoutJuliaParams.setVisibility(View.GONE);
                if (etCentroX.getText().toString().equals("0.0")) {
                    etCentroX.setText("-0.7");
                }
            }
        });

        // Botões de Presets com setOnClickListener
        btnPresetMandelbrot.setOnClickListener(v -> {
            rbMandelbrot.setChecked(true);
            etNome.setText("Mandelbrot Clássico");
            etCentroX.setText("-0.7");
            etCentroY.setText("0.0");
            etZoom.setText("1.0");
            etMaxIter.setText("100");
        });

        btnPresetSeahorse.setOnClickListener(v -> {
            rbMandelbrot.setChecked(true);
            etNome.setText("Vale dos Cavalos-Marinhos");
            etCentroX.setText("-0.743643887");
            etCentroY.setText("0.131825904");
            etZoom.setText("150.0");
            etMaxIter.setText("200");
        });

        btnPresetJulia.setOnClickListener(v -> {
            rbJulia.setChecked(true);
            layoutJuliaParams.setVisibility(View.VISIBLE);
            etNome.setText("Julia Flor de Gelo");
            etCentroX.setText("0.0");
            etCentroY.setText("0.0");
            etZoom.setText("1.0");
            etMaxIter.setText("150");
            etCReal.setText("-0.8");
            etCImag.setText("0.156");
        });

        // Acionamento do botão Calcular via setOnClickListener
        btnCalcular.setOnClickListener(v -> navegarParaDisplayFragment());

        // Acionamento do botão Salvar via setOnClickListener (Persistência SQLite)
        btnSalvarDb.setOnClickListener(v -> salvarConfiguracaoNoBanco());
    }

    private void carregarArgumentosIniciais() {
        Bundle args = getArguments();
        if (args != null) {
            String tipo = args.getString(ARG_TYPE, "Mandelbrot");
            if ("Julia".equalsIgnoreCase(tipo)) {
                rbJulia.setChecked(true);
                layoutJuliaParams.setVisibility(View.VISIBLE);
            } else {
                rbMandelbrot.setChecked(true);
                layoutJuliaParams.setVisibility(View.GONE);
            }

            if (args.containsKey(ARG_NAME)) {
                etNome.setText(args.getString(ARG_NAME));
            }
            if (args.containsKey(ARG_CENTER_X)) {
                etCentroX.setText(String.valueOf(args.getDouble(ARG_CENTER_X)));
            }
            if (args.containsKey(ARG_CENTER_Y)) {
                etCentroY.setText(String.valueOf(args.getDouble(ARG_CENTER_Y)));
            }
            if (args.containsKey(ARG_ZOOM)) {
                etZoom.setText(String.valueOf(args.getDouble(ARG_ZOOM)));
            }
            if (args.containsKey(ARG_MAX_ITER)) {
                etMaxIter.setText(String.valueOf(args.getInt(ARG_MAX_ITER)));
            }
            if (args.containsKey(ARG_C_REAL)) {
                etCReal.setText(String.valueOf(args.getDouble(ARG_C_REAL)));
            }
            if (args.containsKey(ARG_C_IMAG)) {
                etCImag.setText(String.valueOf(args.getDouble(ARG_C_IMAG)));
            }
        }
    }

    /**
     * Alterna dinamicamente para o FractalDisplayFragment utilizando FragmentManager
     * e FragmentTransaction, passando os parâmetros via Bundle e setArguments().
     */
    private void navegarParaDisplayFragment() {
        try {
            String tipo = rbJulia.isChecked() ? "Julia" : "Mandelbrot";
            String nome = etNome.getText().toString().trim();
            if (nome.isEmpty()) {
                nome = "Fractal " + tipo;
            }

            double centroX = Double.parseDouble(etCentroX.getText().toString().trim());
            double centroY = Double.parseDouble(etCentroY.getText().toString().trim());
            double zoom = Double.parseDouble(etZoom.getText().toString().trim());
            int maxIter = Integer.parseInt(etMaxIter.getText().toString().trim());
            double cReal = Double.parseDouble(etCReal.getText().toString().trim());
            double cImag = Double.parseDouble(etCImag.getText().toString().trim());

            // Criação do Bundle para passagem de parâmetros entre Fragments
            Bundle bundle = new Bundle();
            bundle.putString(ARG_TYPE, tipo);
            bundle.putString(ARG_NAME, nome);
            bundle.putDouble(ARG_CENTER_X, centroX);
            bundle.putDouble(ARG_CENTER_Y, centroY);
            bundle.putDouble(ARG_ZOOM, zoom);
            bundle.putInt(ARG_MAX_ITER, maxIter);
            bundle.putDouble(ARG_C_REAL, cReal);
            bundle.putDouble(ARG_C_IMAG, cImag);

            if (getActivity() instanceof com.example.trabalho2.MainActivity) {
                ((com.example.trabalho2.MainActivity) getActivity()).alternarParaDisplayFragment(bundle);
            } else {
                FractalDisplayFragment displayFragment = new FractalDisplayFragment();
                displayFragment.setArguments(bundle);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.setCustomAnimations(
                        android.R.anim.fade_in,
                        android.R.anim.fade_out,
                        android.R.anim.fade_in,
                        android.R.anim.fade_out
                );
                transaction.replace(R.id.fragment_container, displayFragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }

        } catch (NumberFormatException e) {
            Toast.makeText(requireContext(), "Por favor, insira valores numéricos válidos.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Salva a configuração atual no SQLite utilizando ContentValues e insert().
     */
    private void salvarConfiguracaoNoBanco() {
        try {
            String tipo = rbJulia.isChecked() ? "Julia" : "Mandelbrot";
            String nome = etNome.getText().toString().trim();
            if (nome.isEmpty()) {
                nome = "Favorito " + tipo;
            }

            double centroX = Double.parseDouble(etCentroX.getText().toString().trim());
            double centroY = Double.parseDouble(etCentroY.getText().toString().trim());
            double zoom = Double.parseDouble(etZoom.getText().toString().trim());
            int maxIter = Integer.parseInt(etMaxIter.getText().toString().trim());
            double cReal = Double.parseDouble(etCReal.getText().toString().trim());
            double cImag = Double.parseDouble(etCImag.getText().toString().trim());

            FractalDbHelper dbHelper = new FractalDbHelper(requireContext());
            long id = dbHelper.insertFavorite(nome, tipo, centroX, centroY, zoom, maxIter, cReal, cImag);

            if (id != -1) {
                Toast.makeText(requireContext(), "Configuração '" + nome + "' salva com sucesso no SQLite!",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(requireContext(), "Erro ao salvar favorito no SQLite.",
                        Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(requireContext(), "Preencha todos os campos corretamente antes de salvar.",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
