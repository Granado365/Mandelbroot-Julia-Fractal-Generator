package com.example.trabalho2;

import com.example.trabalho2.ui.FractalConfigFragment;

/**
 * Primeiro Fragment da aplicação (Fragment de Configuração).
 * Herda a implementação completa de FractalConfigFragment para gerenciar
 * as entradas dos parâmetros matemáticos dos fractais de Mandelbrot e Julia.
 */
public class FirstFragment extends FractalConfigFragment {

    public FirstFragment() {
        super();
    }
}
