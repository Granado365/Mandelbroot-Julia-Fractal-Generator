package com.example.trabalho2;

import com.example.trabalho2.ui.FractalDisplayFragment;

/**
 * Segundo Fragment da aplicação (Fragment de Exibição).
 * Herda a implementação completa de FractalDisplayFragment para renderização
 * do fractal em Canvas via multithreading com Executors e Callable.
 */
public class SecondFragment extends FractalDisplayFragment {

    public SecondFragment() {
        super();
    }
}
