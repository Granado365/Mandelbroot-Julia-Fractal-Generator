package com.example.trabalho2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.trabalho2.databinding.ActivityMainBinding;
import com.example.trabalho2.ui.FractalConfigFragment;
import com.example.trabalho2.ui.FractalDisplayFragment;
import com.google.android.material.snackbar.Snackbar;

/**
 * MainActivity do aplicativo de Fractais de Mandelbrot e Julia.
 * Herda de AppCompatActivity e utiliza o template Basic Views Activity.
 * Controla os componentes de interface (Button, TextView, EditText) e orquestra
 * a alternância de Fragments Dinâmicos via FragmentManager e FragmentTransaction.
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Insets para ajuste visual com edge-to-edge
        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);

        // Inicialização e uso explícito dos componentes android.widget presentes no layout
        TextView tvHeader = findViewById(R.id.tv_main_header);
        EditText etSessionNotes = findViewById(R.id.et_session_notes);
        Button btnOpenFavorites = findViewById(R.id.btn_open_favorites);
        Button btnOpenWeb = findViewById(R.id.btn_open_web);

        tvHeader.setText(R.string.app_name);
        etSessionNotes.setHint("Anotações da sessão (ex: exploração de órbitas)...");

        // Acionamento de botões via setOnClickListener
        btnOpenFavorites.setOnClickListener(this::onAbrirFavoritosClicked);
        btnOpenWeb.setOnClickListener(this::onAbrirWikiWebClicked);

        // Acionamento de botão via setOnClickListener no FloatingActionButton
        binding.fab.setOnClickListener(view ->
                Snackbar.make(view, "Calculadora e Renderizador de Fractais Mandelbrot & Julia", Snackbar.LENGTH_LONG)
                        .setAnchorView(binding.fab)
                        .setAction("Wiki", this::onAbrirWikiWebClicked)
                        .show()
        );

        // Carrega o Fragment de configuração inicialmente via FragmentManager e FragmentTransaction
        if (savedInstanceState == null) {
            carregarFragmentInicial(getIntent().getExtras());
        }
    }

    @Override
    protected void onNewIntent(@NonNull Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        // Quando uma configuração favorita é selecionada na FavoritesActivity
        carregarFragmentInicial(intent.getExtras());
    }

    /**
     * Utiliza FragmentManager e FragmentTransaction para instanciar dinamicamente
     * o Fragment de configuração e passar parâmetros com Bundle e setArguments().
     */
    private void carregarFragmentInicial(Bundle bundle) {
        FractalConfigFragment configFragment = new FractalConfigFragment();
        if (bundle != null) {
            configFragment.setArguments(bundle);
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragment_container, configFragment);
        transaction.commit();
    }

    /**
     * Transita dinamicamente para o Fragment de exibição passando o Bundle de parâmetros.
     */
    public void alternarParaDisplayFragment(Bundle bundle) {
        FractalDisplayFragment displayFragment = new FractalDisplayFragment();
        displayFragment.setArguments(bundle);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.setCustomAnimations(
                android.R.anim.fade_in,
                android.R.anim.fade_out,
                android.R.anim.fade_in,
                android.R.anim.fade_out
        );
        transaction.replace(R.id.fragment_container, displayFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    /**
     * Acionado via propriedade android:onClick no layout XML ou via setOnClickListener
     * para demonstrar o uso de Intent Explícita para navegar entre diferentes Activities.
     *
     * @param view Botão clicado.
     */
    public void onAbrirFavoritosClicked(View view) {
        // Navegação entre Activities utilizando Intent Explícita
        Intent explicitIntent = new Intent(MainActivity.this, FavoritesActivity.class);
        startActivity(explicitIntent);
    }

    /**
     * Acionado via propriedade android:onClick no layout XML ou via setOnClickListener
     * para demonstrar o uso de Intent Implícita com Intent.ACTION_VIEW para abrir página web.
     *
     * @param view Botão clicado.
     */
    public void onAbrirWikiWebClicked(View view) {
        // Abertura de página web externa utilizando Intent Implícita (Intent.ACTION_VIEW)
        String url = "https://pt.wikipedia.org/wiki/Conjunto_de_Mandelbrot";
        Intent implicitIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

        try {
            startActivity(implicitIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o navegador web.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_favorites) {
            onAbrirFavoritosClicked(null);
            return true;
        } else if (id == R.id.action_wiki) {
            onAbrirWikiWebClicked(null);
            return true;
        } else if (id == R.id.action_settings) {
            Toast.makeText(this, "Aplicativo de Fractais - Versão 1.0", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
